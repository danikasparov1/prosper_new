This module depends on `base_tier_validation`. You can find it at
[OCA/server-ux](https://github.com/OCA/server-ux)

## Module <manufacturing_timesheet>

#### 20.01.2024
#### Version 17.0.1.0.0
#### ADD
- Initial Commit for Manufacturing (MRP) Timesheet

#### 08.11.2024
#### Version 17.0.1.0.0
#### Updated
- Updated the code for adding the value to allocated hours while creating a project task in the MRP work order. Also updated it in index.
# Copyright 2018 Creu Blanca
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import account_loan
from . import account_loan_line
from . import account_move
from . import res_partner

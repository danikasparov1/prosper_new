## Module <bom_product_availability>

#### 12.01.2024
#### Version 17.0.1.0.0
#### ADD

- Initial commit for BOM Product Availability
